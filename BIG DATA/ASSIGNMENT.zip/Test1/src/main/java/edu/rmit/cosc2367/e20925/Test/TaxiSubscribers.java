package edu.rmit.cosc2367.e20925.Test;

//Necessary java packages import for execution

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//Necessary hadoop Imports

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Level;
//Logger library import
import org.apache.log4j.Logger;


/**
 * This is map-reduce program to solve following problem :
 * AWS Data set keeps taxi trip details records for its subscribers called as nyc-tlc taxi details.
 * following is the format
 * Pickup Time Stamp|Drop Off Stamp|Pickup Location|Drop Off Location|TXI Flag|TaxiNumber
 * Now we have to write a map reduce code to find out all Taxi numbers who are making more
 * than 60 minutes of trips in New York city.
 * Call.
 * Source sample: s3a://nyc-tlc/trip data/fhv_tripdata_2018-01.csv
 * 
 * 
 * 
 * 
 * @author SHAMINI PUTHOOPPALLIL BABY
 * 
 */
public class TaxiSubscribers extends Configured implements Tool{

	/**
	 Following code snippet contains SumReducer which is the same code we will use for the Combiner also, 
	 so we do not need to write completely other class but will use the same reducer class and assign it 
	 as a combiner in the driver class(entry point for MapReduce). This class extends the MapReduce Reducer 
	 class and overwrites the reduce() function. The method iterates over the values, adds them and 
	 combines/reduces to a single value/value pairs. Data is moved from mapper class to combiner followed 
	 by the reducer class
	 */
	
	//Get a handle on a Logger instance 
	final static Logger LOG = Logger.getLogger(TaxiSubscribers.class);
	
	public static class SumReducer extends
	Reducer<Text, LongWritable, Text, LongWritable> {
		private LongWritable result = new LongWritable();

		public void reduce(Text key, Iterable<LongWritable> values,
				Reducer<Text, LongWritable, Text, LongWritable>.Context context)
						throws IOException, InterruptedException {
			//For each key value pair, get the value and adds to the sum
	        //to get the total time travelled by each taxi
			LOG.info("Reducer started");
			long sum = 0;
			for (LongWritable val : values) {
				sum += val.get();
			}
			//eliminate the trips with less than 60 minute duration 
			this.result.set(sum);
			if (sum >= 60) {
				//Writes the taxi number  and total time travelled (if >60) as key-value pair to the context
				context.write(key, this.result);
				LOG.info("Reducer Completed");
			}

		}
	}

	/**
	This is the mapper class of TaxiSubscribers which iterates 
	through  each rows of the input data set.
	Input file is separated  by commas and mapper read  each line into  local memory .
	This function extracts trip start time trip end time and taxi numbers from the 
	original data set and calculates the trip duration in milliseconds by 
	minimizing the trip end time from trip start time .
	*/
	public static class TokenizerMapper extends
	Mapper<LongWritable, Text, Text, LongWritable> {

		Text BaseNo = new Text();
		final private static LongWritable durationInMinutes = new LongWritable();

		public void map
		(LongWritable offset, Text text, Context context)
				throws IOException, InterruptedException {
			//Get the text and tokenize the word using comma as separator.
			
			LOG.info("Mapper started");
			String[] parts = text.toString().split(",");
			// extract the relevant fields from the input.
			String tripStartTime = parts[TaxiConstants.tripStartTime].replace("\"","") ;
			String tripEndTime = parts[TaxiConstants.tripEndTime].replace("\"","") ;
			BaseNo.set(parts[TaxiConstants.BaseNo].replace("\"","") );
			//Calculate the total duration in milliseconds of each trip.
			if(tripStartTime!=null &&tripEndTime!=null) {
				long duration = getDateTime(tripEndTime) - getDateTime(tripStartTime);
				durationInMinutes.set(duration / (1000 * 60));
				context.write(BaseNo, durationInMinutes);

			}
		}
		
		/**
		 getDateTime function is designed to check the input format of date time values 
		 are in desired format. Once the passed values matches with the format specified 
		 in the function, it returns the time value from the SimpleDateFormat object  
		 */

		private long getDateTime(String date) {
			long returnVal = -1;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date dateFrm = null;
			//format.setLenient(false);
			try {
				dateFrm = format.parse(date.trim());
				returnVal = dateFrm.getTime();

			} catch (ParseException e) {
				e.printStackTrace();
			}
			return returnVal;
		}
	}

	public int run(String[] args) throws Exception { 
		
		//Create new configuration object and set map reduce job into it
		Configuration conf = getConf();
		conf.set("mapreduce.job.jar", args[2]);

		
		//Create a new Jar and set the driver class(this class) as the main class of jar
		
		//Job job = new Job(configuration, "std");
		Job job=Job.getInstance(conf);
		job.setJarByClass(TaxiSubscribers.class);
		
		
		//Set the map ,combine and reduce classes in the job
		job.setMapperClass(TokenizerMapper.class);
		job.setPartitionerClass(LogPartitioner.class);
		job.setCombinerClass(SumReducer.class);
		job.setReducerClass(SumReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(LongWritable.class);
		
		//Set the number of reducers
		job.setNumReduceTasks(2);
		
		//Set the input and the output path 
		//String inputPath = "/user/shamini/fhv_tripdata_2018-03.csv";
		//String outputPath = "/user/shamini/";
		FileInputFormat.addInputPath(job, new Path(args[0]));
		//FileInputFormat.addInputPath(job, new Path(inputPath));
		FileOutputFormat.setOutputPath(job, new Path(args [1]));
		//FileOutputFormat.setOutputPath(job, new Path(outputPath));
		
		
		
		//Set log-level
		LOG.setLevel(Level.DEBUG);
		LOG.setLevel(Level.ERROR);
		LOG.setLevel(Level.INFO);
		
		//Run the job and wait for its completion
		return job.waitForCompletion(true) ? 0 : -1;
	}
	
   //main function which starts the execution flow.
	public static void main(String[] args) throws Exception {
		System.exit(ToolRunner.run(new TaxiSubscribers(), args));
		
	}
}