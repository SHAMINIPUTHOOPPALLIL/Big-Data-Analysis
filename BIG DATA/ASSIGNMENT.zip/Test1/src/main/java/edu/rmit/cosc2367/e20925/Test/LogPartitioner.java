package edu.rmit.cosc2367.e20925.Test;

//Necessary java packages import for execution
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * LogPartitioner  class designed check  the values from the key-value pair.
 * It automatically splits trip duration into two parts 
 * (0<trip duration<30 minute & 30<trip duration<60 minute)
 *  getPartition function eliminates the trip duration values which is not in the limit * 
 * 
 * @author SHAMINI PUTHOOPPALLIL BABY
 *
 */
public class LogPartitioner extends Partitioner <Text, LongWritable> {
//<IntWritable, IntWritable> {
	private static Logger logger = LoggerFactory.getLogger(LogPartitioner.class);
	public int getPartition(Text key, LongWritable value, int numReduceTasks) {
		logger.info("Partitioner started");
		
		long intValue=value.get();
		if(intValue>=0 && intValue<=60){
			return 1;			
		}else {
			return 0;
		}
		
			
	}
}