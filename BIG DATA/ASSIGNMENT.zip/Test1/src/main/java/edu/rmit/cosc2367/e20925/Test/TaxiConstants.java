package edu.rmit.cosc2367.e20925.Test;

/**
 * 
 * This class is used to store the constant values for the data retrieval
 * of input file.The numbers represents the index values used to search
 * in the file to get the column values from input 
 *
 *
 *@author SHAMINI PUTHOOPPALLIL BABY
 *
 */

public class TaxiConstants {

	public static int fromLocation = 2;
	public static int toLocation = 3;
	public static int tripStartTime = 0;
	public static int tripEndTime = 1;
	public static int BaseNo = 5;

}